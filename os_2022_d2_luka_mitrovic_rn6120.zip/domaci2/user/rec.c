#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#include "kernel/fs.h"

int
main(int argc, char *argv[])
{
	
	int br;
	if(argc < 2){
		printf ("Nedovoljan broj argumenata...\n");
		exit();
	}
	else {
		if ((br = rec(argv[1]))<0)
			printf ("Unet neispravan naziv datoteke\n");		
	}
	exit();
}
