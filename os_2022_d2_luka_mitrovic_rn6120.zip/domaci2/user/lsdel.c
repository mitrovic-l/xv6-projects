#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#include "kernel/fs.h"

int
main(int argc, char *argv[])
{
	char buf[64][14] = {'\0'};
	char *a = &buf[0][0];
	int br;
	if(argc < 2){
		br = lsdel(".", a);
	}
	else 
		br = lsdel(argv[1], a);
	for (int i =0 ;i<br;i++){
	
		for (int j = 0;j<14;j++){
		
			if (buf[i][j]!= '\0')
				printf ("%c", buf[i][j]);
		}		
		printf ("\n");

		
	}
	exit();
}
