#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <pthread.h>
#include<sys/stat.h>
#include<time.h>
#include<string.h>
#include<dirent.h>
#include <unistd.h>
#include "trie.c"		//Funkcije za Trie strukturu
#include "kbhitAlt.c"		//Alternativni kbhit
//Importovan kbhitAlt.c jer u linux-u ne moze include conio.h koji ima kbhit funkciju koja mi je potrebna za stampanje rezultata pretrage.

#define MAX_WORD_LEN 64
#define LETTERS 26

typedef struct helper
{
	char pok[256];
} helper;

typedef struct scanned_file //datoteka koju je scanner vec skenirao
{
        char file_name[256]; //naziv datoteke
        time_t mod_time; //vreme poslednje modifikacije datoteke
} scanned_file;

char* getWord(char *buf, int n);
char* lastWord(char* buf);
int validForSearch(char *word);	
void* scan(void *dir_name);
void loadWords(char buff[]);
void printScannedWords();


pthread_t* scanners;	//Pokazivac na tredove
char *directories[256];	//Pokazivac na direktorijume
int fileCounter = 0;



struct scanned_file scannedFiles[512];
pthread_mutex_t file_mutex;

int main(int argc, char *argv[]){

	trie_init();
	char input[100];
	int scan_num = 0;
	int searchNumber = 1;
	struct helper helper[20];
	int helpCnt =0;	//Redni broj trenutne pretrage
	pthread_t threads[50];
	int thrdCnt = 1;
	
	printf("Unesi komandu\n");
	
	while(strcmp(fgets(input, 100, stdin), "_stop_")){
	
		if(!strcmp(input, "\n"))
			exit(0);
		int i = strlen(input)-1;
		if(input[i] == '\n')
			input[i] = '\0';
		
		
		char copy[100], *first, *second;
		strcpy(copy, input);
		first = getWord(copy,0);
		
		if(!strcmp(first, "_add_")){
			char file_contents[512]; 
			strcpy(copy, input);
			second = getWord(copy, 1);
			//printf("Directory: %s\n", second);
			strcpy(helper[helpCnt].pok, second);
			
			
		    DIR *d;
		    struct dirent *dir;
		    pthread_create(&threads[thrdCnt], NULL, scan, helper+helpCnt);
		    thrdCnt +=1;
		    helpCnt++;
		   
		    scan_num++;
		}
		else if(!strcmp(input, "_stop_")){
			//Prekid rada
			for (int i =0;i<LETTERS;i++){
				pthread_mutex_destroy(&trieMutexArray[i]);
			}
			printf ("Oslobadjanje strukture...\n");
			unloadTrie(head);
			printf("Prekid rada...\n");
			return 0;
		}else{
			char test[100];
			strcpy(test, input);
			//printf(" Za poslednju rec: %s\n", lastWord(test));
			char *zaDsp; zaDsp = lastWord(test);
			if (validForSearch(zaDsp)){	//da li su uneta mala slova
			while(kbhit()){
			
			search(head, zaDsp, searchNumber);
			//printf("Zadnja rec: %s\n", zaDsp);
			}
			} else {
				printf ("Nevalidan unos za pretragu..\n");
				printf("Unesi komandu\n");
				continue;
			}
			//fflush(stdin);
			printf("Prekinuta pretraga\n");
			searchNumber+=1;
		}
			
		
		fflush(stdin);
		printf("Unesi komandu\n");
	}
	
	
	exit(0);


}

//Vraca n-tu rec odvojenu razmakom iz prosledjenog stringa
char* getWord(char *buf, int n){

	char *token = strtok(buf, " ");
	int x = 0;
	while(x <= n){
		
		if(x == n)
			return token;
		x++;	
		token = strtok(NULL, " ");
		
	}
	return NULL;
}
//Vraca poslednju rec odvojenu razmakom, potrebno za pretragu
//kada korisnik unese vise reci uzima se samo poslednja
char* lastWord(char* buf){

	char *token = strtok(buf, " ");
	char *word;
	while(token != NULL){

		word = token;
		token = strtok(NULL, " ");

	}
	//printf("Poslednja rec: %s\n", word);
	return word;
}

//Provera za validnost unosa reci za koju ce se izvrsiti pretraga
int validForSearch(char *word){
	int valid = 1;
	int size = strlen(word);
	for (int i =0;i<size;i++){
		if (*(word+i)>='a' && *(word+i)<='z'){
			continue;
		}
		valid = 0;
	}
	return valid;
}


void* scan(void *dir_name){
	DIR *d;
    	struct dirent *dir;
    	while(1){
    	d = opendir(dir_name);
    	char buff[512];
    	if(d){
		while ((dir = readdir(d)) != NULL) {
		
				if(dir->d_type == 8){
					printf("File: %s\n", dir->d_name); //Provera koji fajl trenutno cita iz prosledjenog direktorijuma.
					int fileExists = 0, fileChanged = 0;
					int fileNumber;
					FILE *fp;
					
					//Kreiranje putanje za fajl..
					char pom[256];
					pom[0] = '\0';
					strcpy(pom, dir_name);
					strcat(pom, "/");
					strcat(pom, dir->d_name);
					
					//Da li fajl vec imamo u nizu skeniranih fajlova?
					for (int i=0;i<fileCounter;i++){
						int exists = strcmp(scannedFiles[i].file_name, dir->d_name);
						if (exists == 0){		//strcmp vrati 0 ako nadje ime fajla u skeniranim
							fileExists = 1;
							//Da li je doslo do neke promene u fajlu?
							struct stat file_stat;
							stat(pom, &file_stat);
							//provera preko vremena zadnje promene
							if (scannedFiles[i].mod_time<file_stat.st_mtime){
								scannedFiles[i].mod_time=file_stat.st_mtime;
								printf("Doslo je do izmene u: %s\n", dir->d_name);
								fp = fopen(pom, "r");
								
								if(fp){
									while(fgets(buff, 512, fp)){	
										loadWords(buff);
									}	
									fclose(fp);
								}
								
							}
						}
					}
					//Ako fajl ne postoji
					if (fileExists == 0){
						struct scanned_file newFile;
						//Podesi mu ime
						strcpy(newFile.file_name, dir->d_name);
						struct stat file_stat;
						stat(pom, &file_stat);
						fp = fopen(pom, "r");
						
						if(fp){
							while(fgets(buff, 512, fp)){
								
								loadWords(buff);
							}	
							fclose(fp);
						}
						
						newFile.mod_time = file_stat.st_mtime;	//podesi vreme zadnje izmene i dodaj ga u niz skeniranih
						scannedFiles[fileCounter] = newFile;
						fileCounter++;
					}
					
				}
		
		}
		
	}
	closedir(d);
	
	sleep(5);
	//printf("Probudio se\n");	
	}
	
}

//Zove se u scan() svaki put kada se ucita nova linija, zove insertWordToTrie() 
void loadWords(char buff[]){
	static int counter = 0;
	char pom[512];
	for (int i =0,j=0;i<strlen(buff);i++){
		 if (buff[i] =='\n' || buff[i] =='\t' || buff[i] ==' '){
			
			//Ukoliko broj slova predje 64, cuvaju se samo prvih 64.
			if (j>MAX_WORD_LEN-1){
				char pompom[512];
				strcpy(pompom, pom);
				strcpy(pom, "");
				strncpy(pom, pompom, MAX_WORD_LEN-1);
			}
			
			int samoSlova = 1;
			int cnt = 0;
			for (int k =0;k<j && k<MAX_WORD_LEN;k++){
				cnt = k;
				if (pom[k]>='a' && pom[k]<='z'){
					continue;
				} else if (pom[k]>='A' && pom[k] <='Z'){
					pom[k] = pom[k] + 32;
				} else {
					samoSlova = 0;
				}
			}
			pom[cnt+1] = '\0';
			if (samoSlova && strcmp(pom, "\n")!=0){
				insertWordToTrie(pom);		//ubaci procitanu rec u srukturu
			}
			j = 0;
			pom[0] = 0;		//resetuj sve da bude spremno za sledecu rec
		} else {
			pom[j++] = buff[i];
		}
	}
}


