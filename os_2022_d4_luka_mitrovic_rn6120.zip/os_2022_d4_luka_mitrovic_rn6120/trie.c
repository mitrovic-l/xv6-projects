#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <pthread.h>

#define LETTERS 26
 
// Converts key current character into index
// use only 'a' through 'z' and lower case
#define CHAR_TO_INDEX(c) ((int)c - (int)'a')
 
// trie node
typedef struct trie_node //cvor unutar trie strukture
{
        char c; //slovo ovog cvora
        int term; //flag za kraj reci
        struct trie_node *parent; //pokazivac ka roditelju
        struct trie_node *children[LETTERS]; //deca
        int timesDisplayed;	//Broji koliko puta je prikazano prilikom pretrage, dodatna promenljiva
} trie_node;


struct trie_node *head;				//Globalni pokazivac na pocetak strukture
pthread_mutex_t trieMutexArray[LETTERS];	//Mutex za svako slovo

void display(struct trie_node* head, char str[], int counter,const char pref[], int searchNumber);

struct trie_node* createTrieNode()
{
	struct trie_node *node = (struct trie_node*)calloc(1, sizeof(struct trie_node));
	node->c = 0;
	node->timesDisplayed = 0;
	node->term = 0;
	node->parent = NULL;
	for (int i=0; i<LETTERS; i++){
		node->children[i] = NULL;
	}
	return node;
}
//Poziva se jednom na pocetku main-a.
void trie_init(){
	head = createTrieNode();
	for(int i = 0; i < LETTERS; i++)
	{
		pthread_mutex_init(&trieMutexArray[i], NULL);
	}
}

//Ubacuje prosledjenu rec u trie strukturu,
//poziva se u loadWords() iz scan() funkcije
void insertWordToTrie(char *arg)
{
	int counter;
	char insert[64];
	strcpy(insert, arg);
	int length = strlen(insert);
	struct trie_node *temp = head;
	int index;

	int lock = CHAR_TO_INDEX(insert[0]);
	pthread_mutex_lock(&trieMutexArray[lock]);
	
	for (counter = 0; counter < length; counter++)		//for petlja koja se krece kroz sve karaktere reci za unos
	{
		index = CHAR_TO_INDEX(insert[counter]);	
		if (index < 0 || index > 25) {
			pthread_mutex_unlock(&trieMutexArray[lock]);
			return;	
		}	
		if (! temp->children[index]){
			temp->children[index] = createTrieNode();
			temp->children[index]->parent = temp;
			char cc = insert[counter];
			temp->children[index]->c = cc;
			cc = '\0';
		}
		temp = temp->children[index];
	}
	if (temp->term == 0)		//setuj flag za poslednje slovo kao kraj reci
		temp->term = 1;
	

	pthread_mutex_unlock(&trieMutexArray[lock]);
}

//Funkcija koja stampa reci za prosledjeni prefix tako sto poziva display f-ju
int search(struct trie_node *head, const char *key, int searchNumber)
{
	int counter;
	int length = strlen(key);
	int index;
	struct trie_node *current = head;
 
    	for (counter = 0; counter < length; counter++)
    	{
        	index = CHAR_TO_INDEX(key[counter]);
 
        	if (!current->children[index])
            		return false;
 
 	
        	current = current->children[index];
    	}
	char buff[64] = "";
	display(current, buff, 0, key, searchNumber);
	
	return true;
}
 

 //Cvor je list ako mu je term setovan na 1
int isLeafNode(struct trie_node* head)
{
	return head->term != 0;
}
  
// Stampa prefiks i string nakon prefiksa, za pretragu
void display(struct trie_node* head, char str[], int counter,const char pref[], int searchNumber)
{

	if (isLeafNode(head)&&head->timesDisplayed<searchNumber)			//onemoguceno visestruko stampanje dodavanjem timesDisplayed u trie node
	{
		str[counter] = '\0';
       		printf("%s%s\n", pref,str);
       		head->timesDisplayed++;
    	}
  
	int i;
    	for (i = 0; i < LETTERS; i++) 
    	{
        	if (head->children[i]) 
        	{
            		str[counter] = i + 'a';				//puni string str karakterima, kada dodje do lista (term=1) ispisuje i povecava timesDisplayed
            		display(head->children[i], str, counter+1, pref, searchNumber);
        	}
    	}
}

//Oslobadjanje strukture, poziva se tek kada se unese _stop_
void unloadTrie(trie_node *head){
	if (head == NULL) 
		return;
	if (head->children == NULL) 
		return;
	for (int i = 0; i < LETTERS; i++) {
		if (head->children[i] != NULL) {
		//printf ("%c, ", head->c);
			unloadTrie(head->children[i]);
			head->children[i] = NULL;
		}
	}
	free(head);
}


