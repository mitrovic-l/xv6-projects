#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "defs.h"
#include "x86.h"
#include "elf.h"

//Pomocna funkcija koja ce se pozvati u exec(), zaduzena za mapiranje struktura
void sharedmemory(struct proc* curproc, pde_t* pgdir){
	static void* mapAddrs = 0x40000000; //Pocetak mapiranja struktura...1GB
	int maxShared  = 10;
	for(int i=0;i<maxShared;i++){
	//cprintf("Usao u sharedmemory za exec\n");
		if (curproc->shrd[i].size!= 0){
		
				pte_t* pte;
				uint offset, frame;
				//Za offset je potrebno zadnjih 12bita, pa radim & sa 0xFFF, tj. PTE_FLAGS..
				offset = PTE_FLAGS((uint)curproc->shrd[i].addrs);
				if (pte = walkpgdirWrapper(curproc->pgdir_parent, curproc->shrd[i].addrs, 0)==0){
					pte  =(pte_t*) kalloc();
					memset(pte, 0, PGSIZE);			
				}
				//Izvlacim adresu od page table entry-a, PTE_ADDR radi & sa negacijom od 0xFFF, da bi izvukao 20bita
				frame = PTE_ADDR(pte);
				
				if (mapsharedWrapper(pgdir, (void*) mapAddrs, (uint) curproc->shrd[i].size, frame, PTE_W | PTE_U)<0){
					freevm(pgdir);
				}
				curproc->shrd[i].addrs = (void*)((uint) mapAddrs|offset);
				cprintf("Exec: %p=addrs, %p\n", curproc->shrd[i].addrs, mapAddrs);
				int add = (PGSIZE -(uint) curproc->shrd[i].size%PGSIZE);
				mapAddrs += (uint) curproc->shrd[i].size + add;
				//(PGSIZE -(uint) curproc->shrd[i].size%PGSIZE) mora jer u suprotnom zove panic,
				//zaokruzi adresu na 0x40001000, 0x40002000,... 
				//Provera
				
		} else 
			break;
			//Cim je nasao strukturu sa size=0 znaci da posle nje nema vise ni jedne, zove break za izlazak..
	}
	return;	
}

int
exec(char *path, char **argv)
{
	char *s, *last;
	int i, off;
	uint argc, sz, sp, ustack[3+MAXARG+1];
	struct elfhdr elf;
	struct inode *ip;
	struct proghdr ph;
	pde_t *pgdir, *oldpgdir;
	struct proc *curproc = myproc();

	begin_op();

	if((ip = namei(path)) == 0){
		end_op();
		cprintf("exec: fail\n");
		return -1;
	}
	ilock(ip);
	pgdir = 0;

	// Check ELF header
	if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))
		goto bad;
	if(elf.magic != ELF_MAGIC)
		goto bad;

	if((pgdir = setupkvm()) == 0)
		goto bad;

	// Load program into memory.
	sz = 0;
	for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
		if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
			goto bad;
		if(ph.type != ELF_PROG_LOAD)
			continue;
		if(ph.memsz < ph.filesz)
			goto bad;
		if(ph.vaddr + ph.memsz < ph.vaddr)
			goto bad;
		if((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
			goto bad;
		if(ph.vaddr % PGSIZE != 0)
			goto bad;
		if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
			goto bad;
	}
	iunlockput(ip);
	end_op();
	ip = 0;

	// Allocate two pages at the next page boundary.
	// Make the first inaccessible.  Use the second as the user stack.
	sz = PGROUNDUP(sz);
	if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
		goto bad;
	clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
	sp = sz;

	// Push argument strings, prepare rest of stack in ustack.
	for(argc = 0; argv[argc]; argc++) {
		if(argc >= MAXARG)
			goto bad;
		sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
		if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
			goto bad;
		ustack[3+argc] = sp;
	}
	ustack[3+argc] = 0;

	ustack[0] = 0xffffffff;  // fake return PC
	ustack[1] = argc;
	ustack[2] = sp - (argc+1)*4;  // argv pointer

	sp -= (3+argc+1) * 4;
	if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
		goto bad;

	// Save program name for debugging.
	for(last=s=path; *s; s++)
		if(*s == '/')
			last = s+1;
	safestrcpy(curproc->name, last, sizeof(curproc->name));

	// Commit to the user image.
	oldpgdir = curproc->pgdir;
	curproc->pgdir = pgdir;
	curproc->sz = sz;
	curproc->tf->eip = elf.entry;  // main
	curproc->tf->esp = sp;
	switchuvm(curproc);
	freevm(oldpgdir);
	
	
	//Exec() izmena:
	sharedmemory(curproc, pgdir);
	
	
	return 0;

	bad:
	if(pgdir)
		freevm(pgdir);
	if(ip){
		iunlockput(ip);
		end_op();
	}
	return -1;
}
