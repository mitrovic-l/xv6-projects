
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#include "kernel/fs.h"


int
main(int argc, char *argv[])
{
	int i,pid,wpid,br=0;
	char i1[20]="SHARED1";
	char i2[20]="SHARED2";
	char i3[20]="SHARED3";
	char i4[20]="SHARED4";
	

	i=share_mem(i1,(void*)0x41,12);
	i=share_mem(i2,(void*)0x79,7);
	i=share_mem(i3,(void*)0x101,90);
	i=share_mem(i4,(void*)0x121,13);
	
	
	//Iskopirano iz init.c-a, kao provera za fork() i za exec() izmene...
	for(;;){
		br=1;
		pid = fork();
		if(pid < 0){
			printf("init: fork failed\n");
			exit();
		}
		if(pid == 0){
			exec("/bin/primecom",argv);
			printf("init: exec sh failed\n");
			exit();
		}	
		while((wpid=wait()) >= 0 && wpid != pid){
				printf("Error\n");
		}				
		if(br)break;
	}

	exit();
	
}

