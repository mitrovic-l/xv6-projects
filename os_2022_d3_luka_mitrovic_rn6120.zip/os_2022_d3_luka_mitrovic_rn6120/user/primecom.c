#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#include "kernel/fs.h"


int
main(int argc, char *argv[])
{
	int i;
	void* addrs;
	//Samo za testiranje get_shareda i prosledjivanje pokazivaca
	i = get_shared("SHARED2", (void*)&addrs);
	printf("Pokazivac addrs nakon get_shared: %p\n", addrs);
	i = get_shared("SHARED3", (void*)&addrs);
	printf("Pokazivac addrs nakon get_shared: %p\n", addrs);
	exit();
}
